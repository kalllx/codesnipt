package com.kalllx.exception.util;

public interface JsonObjectProcess<T>
{
 public T process();
}
